import json
import logging
import time
import os
import sys

import boto3
import cfnresponse
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

envLambdaTaskRoot = os.environ["LAMBDA_TASK_ROOT"]
logger.info("LAMBDA_TASK_ROOT env var:"+os.environ["LAMBDA_TASK_ROOT"])
logger.info("sys.path:"+str(sys.path))

sys.path.insert(0,envLambdaTaskRoot+"/boto3")
logger.info("sys.path:"+str(sys.path))


def lambda_handler(event, context):
  responseStatus = cfnresponse.SUCCESS
  responseData = {}

  logger.info("Launch:full event")
  logger.info(json.dumps(event))     
  logger.info("boto3 version %s", boto3.__version__)

  if event["RequestType"] == "Delete":    
    logger.info("Delete is always OK")
  elif event["RequestType"] == "Create" or event["RequestType"] == "Update":
    logger.info("Create or Update")

    try:
      client = boto3.client("autoscaling")
      logger.info("set client SUCCESS")
    except:
      logger.info("set client FAIL")
      cfnresponse.send(event, context, responseStatus, responseData)

    try:
      FirewallASGVar = event["ResourceProperties"]["FirewallASGVar"] 
      MinSizeVar = event["ResourceProperties"]["MinSizeVar"] 
      MaxSizeVar = event["ResourceProperties"]["MaxSizeVar"] 
      WarmMinSizeVar = event["ResourceProperties"]["WarmMinSizeVar"] 
      DesiredCapacityVar = event["ResourceProperties"]["DesiredCapacityVar"] 
      logger.info("set vars SUCCESS: %s %s %s %s %s", FirewallASGVar, MinSizeVar, MaxSizeVar, DesiredCapacityVar, WarmMinSizeVar)
    except:
      logger.info("set vars FAIL")
      cfnresponse.send(event, context, responseStatus, responseData)
      
    try:
      response = client.update_auto_scaling_group(
        AutoScalingGroupName = FirewallASGVar,
        MinSize = int(MinSizeVar),
        MaxSize = int(MaxSizeVar),
        DesiredCapacity = int(DesiredCapacityVar),
      )
      logger.info("autoscale update success: %s", response)
      responsewarm = client.put_warm_pool(
          AutoScalingGroupName = FirewallASGVar,
          MinSize = int(WarmMinSizeVar)
      )      
      logger.info("warm pool update SUCCESS: %s", responsewarm)
    except:
      logger.info("autoscale update FAIL") 
      cfnresponse.send(event, context, responseStatus, responseData) 
        
  logger.info("The End") 
  cfnresponse.send(event, context, responseStatus, responseData)
