"""
/*****************************************************************************
 * Copyright (c) 2016, Palo Alto Networks. All rights reserved.              *
 *                                                                           *
 * This Software is the property of Palo Alto Networks. The Software and all *
 * accompanying documentation are copyrighted.                               *
 *****************************************************************************/

Copyright 2016 Palo Alto Networks

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

import boto3
from botocore.config import Config
import logging
import json
import http.client
import xml.etree.ElementTree as et
import time
from urllib.parse import urlparse
import urllib.parse
from contextlib import closing
import ssl
import decimal
import uuid
import sys
import urllib
import hashlib
import base64
from boto3.dynamodb.conditions import Key, Attr
from time import *
import os
import time

logger = logging.getLogger()
logger.setLevel(logging.INFO)
logger.debug("Warm: AWS DATA PATH before: ")
logger.debug(os.environ.get('AWS_DATA_PATH', ''))

s3 = boto3.client('s3')
ec2 = boto3.resource('ec2')
ec2_client = ec2.meta.client

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

LIFECYCLE_KEY = "LifecycleHookName"
ASG_KEY = "AutoScalingGroupName"
EC2_KEY = "EC2InstanceId"
DOCUMENT_NAME = "ASGLogBackup"
RESPONSE_DOCUMENT_KEY = "DocumentIdentifiers"


def lambda_handler(event, context):
    logger.debug("Warm:full event")
    logger.debug(json.dumps(event))
    message = event['detail']
    logger.debug("Warm:message var")
    logger.debug(json.dumps(message))
    instanceId = message['EC2InstanceId']
    logger.info("Warm:instanceID var: %s", instanceId)
    metadata = message['NotificationMetadata']

    fwApiKey=metadata['KeyPANWFirewall']
    s3bucketvar=metadata['s3bucket']
    KeyPANWPanorama=metadata['KeyPANWPanorama']
    logger.debug("Warm:fwApiKey var: %s", fwApiKey)
    
    # try:
    #     logger.info("Warm:entering Try section of handler ")
    #     logger.debug(json.dumps(event))    
    # except Exception as e:
    #     logger.error("Error: %s", str(e))

    logger.debug("Warm:Client IP address")
    instance = ec2.Instance(instanceId)
    logger.debug("Warm:full instance var: %s", instance)
    gwMgmtIp = instance.network_interfaces[1].private_ip_address
    logger.info("Warm:IP addresss eth0: %s", gwMgmtIp)
    # logger.info("Warm:IP address eth1: %s", instance.network_interfaces[1].private_ip_address)

    ## Check if Firewall Up
    matchText = '<result>OK</result>'
    job_id = '2'
    while (True):
        try:
            cmd = urllib.request.Request("https://" + gwMgmtIp + "/api/?type=op&cmd=<show><jobs><id>"+job_id+"</id></jobs></show>&key=" + fwApiKey)
            logger.debug("Warm:output of the urllib cmd create %s", cmd) 
            urlcall = urllib.request.urlopen(cmd, data=None, context=ctx, timeout=5)
            logger.debug("Warm:[urlcall]: %s", urlcall) 
            response = urlcall.read()
            # response = urllib.request.urlopen(cmd, data=None, timeout=5).read()
            logger.info("Warm:[RESPONSE]: %s", response) 
            if matchText in str(response):
                logger.info("Warm:matchtext in the response body")
                break
            else:
                logger.info("Warm:commit missing") 
                time.sleep(30) 
                continue             
        except (urllib.error.URLError, urllib.error.HTTPError) as e: 
            logger.info("Warm:[INFO]: No response from FW in workaround. So maybe not up! without cache {}".format(e))
            time.sleep(30) 
            # return 'no'
        # except urllib.socket.timeout as e:
        #     logger.error('socket timed out - URL %s', e)    
        #     #logger.error('socket timed out - error %s', e1)   
        #     time.sleep(30) 
        except:
            logger.error('catchall urlopen Except error')
            time.sleep(30) 
        else:
            logger.info("Warm:[INFO]: Instance is down!!")   
            time.sleep(30) 



    ### Get Panorama IP Address
    try:
        cmd_get_panorama = urllib.request.Request("https://" + gwMgmtIp + "/api/?type=config&action=get&xpath=/config/devices/entry[@name='localhost.localdomain']/deviceconfig/system/panorama&key=" + fwApiKey)
        #cmd_get_panorama = urllib.request.Request("https://" + gwMgmtIp + "/api/?type=op&cmd=<show><panorama-status></panorama-status></show>&key=" + fwApiKey)
        logger.debug("Warm:output of get panorama %s", cmd_get_panorama) 
        urlcall_get_panorama = urllib.request.urlopen(cmd_get_panorama, data=None, context=ctx, timeout=5)
        logger.debug("Warm:output of urlopen panorama %s", urlcall_get_panorama) 
        response_get_panorama = urlcall_get_panorama.read().decode('utf-8')
        logger.info("Warm:[RESPONSE]: %s", response_get_panorama) 
        resp_get_panorama = et.fromstring(response_get_panorama) 
        logger.debug("text before panorama fine")
        logger.debug("Warm:[Panorama et root]: %s::%s", resp_get_panorama.tag, resp_get_panorama.attrib) 
        panoramaIPelement = resp_get_panorama.findall(".//panorama-server")
        panoramaIP = panoramaIPelement[0].text
        logger.info("Warm:[Panorama IP]: %s", panoramaIP) 
    except:
        logger.error('Warm: Get Panorama failed')


    ## Get Firewall Serial number and Host name
    try:
        cmd_get_fw_serial = urllib.request.Request("https://" + gwMgmtIp + "/api/?type=op&cmd=<show><system><info/></system></show>&key=" + fwApiKey)
        #cmd_get_fw_serial = urllib.request.Request("https://" + gwMgmtIp + "/api/?type=op&cmd=<show><fw_serial-status></fw_serial-status></show>&key=" + fwApiKey)
        logger.debug("Warm:output of get serial %s", cmd_get_fw_serial) 
        urlcall_get_fw_serial = urllib.request.urlopen(cmd_get_fw_serial, data=None, context=ctx, timeout=5)
        logger.debug("Warm:output of urlopen fw_serial %s", urlcall_get_fw_serial) 
        response_get_fw_serial = urlcall_get_fw_serial.read().decode('utf-8')
        logger.info("Warm:[RESPONSE]: %s", response_get_fw_serial) 
        resp_get_fw_serial = et.fromstring(response_get_fw_serial) 
        logger.debug("text before fw_serial fine")
        logger.debug("Warm:[fw_serial et root]: %s::%s", resp_get_fw_serial.tag, resp_get_fw_serial.attrib)         
        fw_serialelement = resp_get_fw_serial.findall(".//serial")
        fw_serial = fw_serialelement[0].text
        fw_hostnameelement = resp_get_fw_serial.findall(".//hostname")
        fw_hostname = fw_hostnameelement[0].text
        logger.info("Warm:[fw_serial IP]: %s", fw_serial) 
        logger.info("Warm:[fw_hostname IP]: %s", fw_hostname) 
    except:
        logger.error('Warm: Get fw_serial failed')  

    ## Get DG and TS name THIS ASSUMES init-cfg.txt in bootstrap
    initkey = "config/init-cfg.txt"    
    key = urllib.parse.unquote_plus(initkey)    
    try:
        response = s3.get_object(Bucket=s3bucketvar, Key=key)
        logger.debug("CONTENT TYPE: " + response['ContentType'])
        initcfgcontents=response['Body'].read().decode('utf-8')
        logger.debug("Contents var: %s", initcfgcontents)
    except Exception as e:
        logger.error("Error: %s", str(e))
        logger.error('Error getting object {} from bucket {}. Make sure they exist.'.format(key, s3bucketvar))
    s3dict = get_values_from_init_cfg(initcfgcontents)
    logger.debug('Panorama: Init CFG bootstrap file Panorama settings is as follows: ')
    logger.debug(s3dict)
    PanoramaDG=s3dict['dgname']
    PanoramaTPL=s3dict['tplname']
    logger.info("Warm: DG: %s, Temlate: %s", PanoramaDG, PanoramaTPL) 


    # Panorama Push to Device        
    try:
        # cmd_panorama_commit = urllib.request.Request("https://" + panoramaIP + "/api/?type=commit&cmd=<commit></commit>&key="+ KeyPANWPanorama)
        cmd_panorama_commit = urllib.request.Request("https://" + panoramaIP + "/api/?type=commit&action=all&cmd=<commit-all><shared-policy><include-template>yes</include-template><device-group><entry%20name=%22" + PanoramaDG + "%22><devices><entry%20name=%22" + fw_serial + "%22/></devices></entry></device-group></shared-policy></commit-all>&key="+ KeyPANWPanorama)
        logger.debug("Warm:output of Panorama Commit %s", cmd_panorama_commit) 
        urlcall_panorama_commit = urllib.request.urlopen(cmd_panorama_commit, data=None, context=ctx, timeout=5)
        logger.debug("Warm:output of urlopen Panorama Commit %s", urlcall_panorama_commit) 
        response_panorama_commit = urlcall_panorama_commit.read().decode('utf-8')
        logger.info("Warm:[Panorama Commit Result]: %s", response_panorama_commit) 
    except: 
        logger.error('Warm: Panorama Commit failed')        



    ## Release Lifecycle Hook
    logger.debug("Warm:logging after after URL Call")          
    asgClient = boto3.client('autoscaling')
    lifeCycleHook = message['LifecycleHookName']
    autoScalingGroup = message['AutoScalingGroupName']

    logger.debug("Warm:logging before response")  
    actionResult = "CONTINUE"
    response = asgClient.complete_lifecycle_action(
        LifecycleHookName = lifeCycleHook,
        AutoScalingGroupName = autoScalingGroup,
        LifecycleActionResult = actionResult,
        InstanceId = instanceId
    )
    logger.debug("Warm:logging vars after response")  
    logger.debug(response)  
    logger.debug(asgClient)  
    logger.debug(lifeCycleHook)  
    logger.debug(autoScalingGroup)  

def get_values_from_init_cfg(contents):
    """
    Retrieve the keys from the init-cfg file
    :param contents:
    :return: dict
    """
    d = {'panorama-server': "", 'tplname': "", 'dgname': "", 'hostname': ""}
    if contents is None:
        return d

    contents=contents.replace('\n', '::')
    list=contents.split("::")
    for i in list:
        if i == "":
            continue

        s=i.split("=")
        if s[0] != "" and s[0] == "panorama-server" and s[1] != "":
            d['panorama-server']=s[1]
        elif s[0] != "" and s[0] == "tplname" and s[1] != "":
            d['tplname']=s[1]
        elif s[0] != "" and s[0] == "dgname" and s[1] != "":
            d['dgname']=s[1]
        elif s[0] != "" and s[0] == "hostname" and s[1] != "":
            d['hostname']=s[1]

    return d       
